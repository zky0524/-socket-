package svr;

import java.io.IOException;

import svr.ui.ServerUi;

public class main {
	public static void main(String[] args) throws IOException{
		new ServerUi();
	}
}
